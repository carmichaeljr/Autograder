Test Student 3


float hash=0.0;
String temp=new String();
for (int i=0; i<temp.length; i++){
	int other=temp.length-i;
	hash+=(temp[other]*temp[i]);
}
System.out.println(hash);